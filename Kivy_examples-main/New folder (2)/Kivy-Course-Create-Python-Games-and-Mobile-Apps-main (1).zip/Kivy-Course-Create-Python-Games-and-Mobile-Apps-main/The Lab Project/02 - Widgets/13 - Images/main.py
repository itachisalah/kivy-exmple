from kivy.app import App


class LabApp(App):
    pass


if __name__ == '__main__':
    LabApp().run()
