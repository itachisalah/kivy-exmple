from kivy.app import App
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout


class ExemploBoxLayout(BoxLayout):
    """def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # Configurar a orientação da tela
        self.orientation = 'vertical'

        # Criar os botões
        b1 = Button(text='A')
        b2 = Button(text='B')
        b3 = Button(text='C')

        # Adicionar os botões na tela
        self.add_widget(b1)
        self.add_widget(b2)
        self.add_widget(b3)"""
    pass


class LabApp(App):
    pass


if __name__ == '__main__':
    LabApp().run()
