from kivy.app import App
from kivy.uix.anchorlayout import AnchorLayout


class ExemploAnchorLayout(AnchorLayout):
    pass


class LabApp(App):
    pass


if __name__ == '__main__':
    LabApp().run()
