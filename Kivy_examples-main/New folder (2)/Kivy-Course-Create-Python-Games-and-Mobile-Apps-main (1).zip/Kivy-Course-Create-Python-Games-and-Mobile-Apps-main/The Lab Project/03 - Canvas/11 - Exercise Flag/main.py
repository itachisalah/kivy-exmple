from kivy.app import App
from kivy.uix.widget import Widget
from kivy.uix.boxlayout import BoxLayout


class ExemploCanvas(BoxLayout):
    pass


class LabApp(App):
    pass


if __name__ == '__main__':
    LabApp().run()
