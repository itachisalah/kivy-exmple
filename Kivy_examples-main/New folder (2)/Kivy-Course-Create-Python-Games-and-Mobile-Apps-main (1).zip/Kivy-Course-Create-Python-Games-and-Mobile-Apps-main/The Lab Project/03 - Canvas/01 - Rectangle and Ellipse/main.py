from kivy.app import App
from kivy.uix.widget import Widget


class ExemploCanvas(Widget):
    pass


class LabApp(App):
    pass


if __name__ == '__main__':
    LabApp().run()
