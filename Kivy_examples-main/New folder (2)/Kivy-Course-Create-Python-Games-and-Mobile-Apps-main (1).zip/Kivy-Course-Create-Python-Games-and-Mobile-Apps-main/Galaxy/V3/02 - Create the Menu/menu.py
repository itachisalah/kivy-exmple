from kivy.uix.relativelayout import RelativeLayout


class MenuWidget(RelativeLayout):
    pass