from kivymd.uix.screen import MDScreen


class ListScreenView(MDScreen):
    pass
