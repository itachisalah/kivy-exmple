from .onescreen.components.cardcity.card_city import CityCard
from .onescreen.one_screen import OneScreenView
from .twoscreen.two_screen import TwoScreenView
