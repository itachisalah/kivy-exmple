from kivy.properties import StringProperty

from kivymd.uix.list import OneLineIconListItem


class OneLineItem(OneLineIconListItem):
    icon = StringProperty()
