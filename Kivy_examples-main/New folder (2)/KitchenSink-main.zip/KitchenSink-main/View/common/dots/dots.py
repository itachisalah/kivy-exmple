from kivymd.uix.boxlayout import MDBoxLayout


class Dots(MDBoxLayout):
    """Implements a screens indicator as OnBoard."""
