from kivymd.uix.card import MDCard


class RectangularCard(MDCard):
    pass
