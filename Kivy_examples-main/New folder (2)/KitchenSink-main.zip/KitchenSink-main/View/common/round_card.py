from kivymd.uix.card import MDCard


class RoundCard(MDCard):
    pass
