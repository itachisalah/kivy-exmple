from kivymd.uix.screen import MDScreen


class ButtonScreenTwoScreen(MDScreen):
    pass
