from kivymd.uix.screen import MDScreen


class ButtonScreenOneScreen(MDScreen):
    pass
