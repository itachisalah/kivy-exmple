screens = {
    "about": "AboutScreen.about_screen",
    "button": "ButtonScreen.button_screen",
    "card": "CardScreen.card_screen",
    "chip": "ChipScreen.chip_screen",
    "field": "FieldScreen.field_screen",
    "menu": "MenuScreen.menu_screen",
    "list": "ListScreen.list_screen",
    "sliver": "SliverScreen.sliver_screen",
    "rail": "NavigationrailScreen.navigationrail_screen",
    "tile": "ImageListScreen.imagelist_screen",
    "hero": "HeroAnimationScreen.hero_animation_screen",
}
