from .onescreen.one_screen import OneScreen
from .twoscreen.two_screen import TwoScreen
from .thirdscreen.third_screen import ThirdScreen
