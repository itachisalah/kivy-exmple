from kivymd.uix.screen import MDScreen
from kivymd.uix.behaviors import StencilBehavior


class OneScreen(MDScreen, StencilBehavior):
    pass
