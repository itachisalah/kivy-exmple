from kivymd.uix.screen import MDScreen
from kivymd.uix.behaviors import StencilBehavior


class TwoScreen(MDScreen, StencilBehavior):
    pass
