from kivymd.uix.screen import MDScreen
from kivymd.uix.behaviors import StencilBehavior

from View.common.rectangular_card import RectangularCard  # NOQA


class ThirdScreen(MDScreen, StencilBehavior):
    pass
