from kivymd.uix.screen import MDScreen

from View.CardScreen.components import CardProfile  # NOQA
from View.CardScreen.components import CardMessage  # NOQA
from View.CardScreen.components import CardCall  # NOQA
from View.CardScreen.components import CardNotification  # NOQA


class CardScreenView(MDScreen):
    pass
