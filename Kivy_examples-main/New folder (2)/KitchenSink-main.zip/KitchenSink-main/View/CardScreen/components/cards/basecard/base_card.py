from View.common.rectangular_card import RectangularCard


class BaseCard(RectangularCard):
    pass
