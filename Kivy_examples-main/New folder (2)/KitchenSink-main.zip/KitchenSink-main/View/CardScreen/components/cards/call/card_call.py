from kivy.properties import StringProperty

from View.CardScreen.components.cards.basecard import BaseCard


class CardCall(BaseCard):
    name_caller = StringProperty()
