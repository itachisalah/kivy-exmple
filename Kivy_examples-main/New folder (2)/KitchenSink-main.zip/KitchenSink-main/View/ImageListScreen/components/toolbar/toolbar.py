from kivy.properties import StringProperty

from View.common.rectangular_card import RectangularCard


class ImageListScreenToolbar(RectangularCard):
    title = StringProperty()
