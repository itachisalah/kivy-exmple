# KitchenSink

### Demo application of the [KivyMD](https://github.com/kivymd/KivyMD) library widgets

[![APK build](https://github.com/kivymd/KitchenSink/actions/workflows/main.yml/badge.svg)](https://github.com/kivymd/KitchenSink/actions/workflows/main.yml)

<p align="center">
    <img 
        width="720" 
        src="https://github.com/kivymd/KitchenSink/blob/main/assets/images/preview.png"
    >
</p>

These are collections of simple stylish and modern user interface design for mobile and desktop applications.
You can download the test `APK` packages of the demo application on [this](https://github.com/kivymd/KitchenSink/actions/workflows/main.yml)
page by selecting the most recent commit, download the `package` archive, unpack it and install it on your phone.
### This project is under development.
