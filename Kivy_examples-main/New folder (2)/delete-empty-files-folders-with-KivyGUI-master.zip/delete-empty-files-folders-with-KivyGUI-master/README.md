WON'T WORK WITHOUT KIVY FRAMEWORK!.

This is an intermediate python project.With a GUI(Kivy)
Final Release.Can still be improved.

It helps clean out empty files and folders. Also provides a controlled level scanning.
This can be configured in the settings aspect of the app.The larger the value,the more subdirectories can be effectively cleaned out.
***SHOULD NOT BE SET MORE THAN 30

It is written in OOP.
Basically this project should be compiled into an android app but will do just fine if ran on an interpreter.
It can also run on any system as long as the the file system dir is adjusted.(Note:This script was initially written and ran with Pydroid:An android IDE)

Dependencies:
Kivy framework.

It helps display a GUI which provides a sufficient abstraction to access various class methods.
