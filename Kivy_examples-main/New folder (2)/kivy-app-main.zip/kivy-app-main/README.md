# kivy-app
this is basic gui application with kivy. 
Kivy is a python gui library similar to Tkinter and PyQt.
Make sure to install virtual environment before you run the project
