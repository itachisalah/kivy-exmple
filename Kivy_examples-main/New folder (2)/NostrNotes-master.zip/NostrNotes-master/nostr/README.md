Copied python-nostr from https://github.com/jeffthibault/python-nostr
