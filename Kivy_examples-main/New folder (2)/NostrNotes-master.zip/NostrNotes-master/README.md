# NostrNotes
Simple notes app with GUI and automatic encrypted backup on Nostr relays

![Bildschirmfoto vom 2022-11-25 15-53-01](https://user-images.githubusercontent.com/51097237/204011282-1d6b183e-2c1c-4a26-b76d-e17606d5b74a.png)

What is Nostr:
https://github.com/nostr-protocol/nostr
